package plataforma.integracion;

public interface HerramientaExterna {
    void obtenerDatos();
}