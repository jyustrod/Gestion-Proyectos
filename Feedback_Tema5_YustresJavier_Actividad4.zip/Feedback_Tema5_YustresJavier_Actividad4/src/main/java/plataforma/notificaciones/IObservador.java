package plataforma.notificaciones;

public interface IObservador {
    void actualizar();
}