package plataforma.tareas;

public abstract class FabricaTareas {
    public abstract Tarea crearTarea(String nombre);
}